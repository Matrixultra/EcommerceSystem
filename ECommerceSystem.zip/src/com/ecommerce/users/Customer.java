package com.ecommerce.users;

public class Customer {
    private String name;
    private String email;

    public Customer(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public void display() {
        System.out.println("Customer: " + name + " | " + email);
    }
}

package com.ecommerce;

import com.ecommerce.products.*;
import com.ecommerce.cart.*;
import com.ecommerce.orders.*;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<Product> products = new ArrayList<>();
        products.add(new ElectronicsProduct("E1", "Phone", 50000, "Smartphone", 10, "Samsung"));
        products.add(new ClothingProduct("C1", "T-Shirt", 1000, "Cotton", 50, "M"));
        products.add(new BookProduct("B1", "Java Book", 800, "Learn Java", 20, "John"));

        ShoppingCart cart = new ShoppingCart();

        while (true) {
            System.out.println("\n1.View 2.Add 3.Cart 4.Checkout 5.Exit");
            int ch = sc.nextInt();

            if (ch == 1) {
                for (Product p : products) {
                    p.display();
                }
            } else if (ch == 2) {
                System.out.print("Enter ID: ");
                String id = sc.next();

                for (Product p : products) {
                    if (p.getId().equals(id)) {
                        System.out.print("Qty: ");
                        int q = sc.nextInt();
                        cart.addItem(new CartItem(p, q));
                    }
                }
            } else if (ch == 3) {
                cart.displayCart();
            } else if (ch == 4) {
                Order order = new Order(cart);
                order.displayOrder();
            } else break;
        }
    }
}

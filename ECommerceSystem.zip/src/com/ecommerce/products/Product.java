package com.ecommerce.products;

public abstract class Product {
    protected String id;
    protected String name;
    protected double price;
    protected String description;
    protected int stock;

    public Product(String id, String name, double price, String description, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.stock = stock;
    }

    public abstract double calculateDiscount();

    public double getFinalPrice() {
        return price - calculateDiscount();
    }

    public String getId() { return id; }
    public String getName() { return name; }

    public void display() {
        System.out.println(id + " | " + name + " | ₹" + getFinalPrice());
    }
}

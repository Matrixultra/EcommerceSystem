package com.ecommerce.products;

public class BookProduct extends Product {
    private String author;

    public BookProduct(String id, String name, double price, String desc, int stock, String author) {
        super(id, name, price, desc, stock);
        this.author = author;
    }

    @Override
    public double calculateDiscount() {
        return price * 0.05;
    }
}

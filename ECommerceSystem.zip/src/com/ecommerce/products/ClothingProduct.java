package com.ecommerce.products;

public class ClothingProduct extends Product {
    private String size;

    public ClothingProduct(String id, String name, double price, String desc, int stock, String size) {
        super(id, name, price, desc, stock);
        this.size = size;
    }

    @Override
    public double calculateDiscount() {
        return price * 0.15;
    }
}

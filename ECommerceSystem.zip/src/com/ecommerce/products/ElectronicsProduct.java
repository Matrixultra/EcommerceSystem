package com.ecommerce.products;

public class ElectronicsProduct extends Product {
    private String brand;

    public ElectronicsProduct(String id, String name, double price, String desc, int stock, String brand) {
        super(id, name, price, desc, stock);
        this.brand = brand;
    }

    @Override
    public double calculateDiscount() {
        return price * 0.10;
    }
}

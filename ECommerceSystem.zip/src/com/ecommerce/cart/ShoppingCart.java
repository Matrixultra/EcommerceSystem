package com.ecommerce.cart;

import java.util.*;

public class ShoppingCart {
    private List<CartItem> items = new ArrayList<>();

    public void addItem(CartItem item) {
        items.add(item);
    }

    public double getTotal() {
        double total = 0;
        for (CartItem item : items) {
            total += item.getTotal();
        }
        return total;
    }

    public void displayCart() {
        for (CartItem item : items) {
            System.out.println(item.getProduct().getName() + " x " + item.getQuantity());
        }
        System.out.println("Total: ₹" + getTotal());
    }

    public List<CartItem> getItems() {
        return items;
    }
}

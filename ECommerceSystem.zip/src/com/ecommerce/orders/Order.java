package com.ecommerce.orders;

import com.ecommerce.cart.ShoppingCart;

public class Order {
    private static int count = 1000;
    private String orderId;
    private ShoppingCart cart;

    public Order(ShoppingCart cart) {
        this.cart = cart;
        this.orderId = "ORD" + count++;
    }

    public void displayOrder() {
        System.out.println("Order ID: " + orderId);
        cart.displayCart();
        double total = cart.getTotal();
        double gst = total * 0.18;
        System.out.println("GST: ₹" + gst);
        System.out.println("Final: ₹" + (total + gst));
    }
}
